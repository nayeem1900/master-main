import React, { Component } from 'react';

class UserPermission extends Component {
    render() {
        return (
            <div>
                <h1>User Permissions</h1>
            </div>
        );
    }
}

export default UserPermission;