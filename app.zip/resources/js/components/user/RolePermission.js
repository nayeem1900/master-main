import React, { Component } from 'react';

class Rolepermission extends Component {
    render() {
        return (
            <div>
                <div class="col-md-12 pt-2">
                    <div class="card card-default">
                        <div class="card-header">
                            <h3 class="card-title">Role Permission</h3>
                            
                                <div class="col-sm-3">
                                    <select class="form-control select2">
                                        <option selected="selected">Alabama</option>
                                        <option>Alaska</option>
                                        <option>California</option>
                                        <option>Delaware</option>
                                        <option>Tennessee</option>
                                        <option>Texas</option>
                                        <option>Washington</option>
                                    </select>
                                </div>
                                
                            
                            <div class="card-body">
                                hello
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Rolepermission;
