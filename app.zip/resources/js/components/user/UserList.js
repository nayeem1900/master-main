import React, { Component } from 'react';

class UserList extends Component {
    render() {
        return (
            <div>
                <h1>User List</h1>
            </div>
        );
    }
}

export default UserList;